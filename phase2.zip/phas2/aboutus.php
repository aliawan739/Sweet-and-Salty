<html>
    <head>
        <title>About Us</title>

        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    
        
        
    </head>
    <body>
<!--------------------------------------------------------HEADER---------------------------------------------------------->
<a href="http://localhost/phas2/home.php"><img src="logo.png"></a>
        <a href="https://www.facebook.com/"><img src="fb.png" class="rounded float-right"  alt="responsive"></a>
        <a href="https://www.instagram.com/"><img src="insta.png" class="rounded float-right"  alt="responsive"></a>
        <a href="https://web.whatsapp.com/"><img src="whatsapp.png" class="rounded float-right"  alt="responsive"></a> 
        <a href="https://twitter.com/"><img src="tweet.png" class="rounded float-right"  alt="responsive"></a>

<!---------------------------------------------------------NAVBAR---------------------------------------------------------->
        <nav class="navbar navbar-right" style="background-color:rgba(0, 0, 0, 0.747); ">
            <a style="color: white;" href="http://localhost/phas2/home.php">Home</a>
            <a style="color: white;" href="http://localhost/phas2/aboutus.php">About US</a>
            <a style="color: white;" href="http://localhost/phas2/products.php">Products</a>
            <a style="color: white;" href="http://localhost/phas2/contactus.php">Contact Us</a>
            <a style="color: white;" href="http://localhost/phas2/login.php">Login/Register</a>
        
        </nav>


<!-----------------------------------------------------About Business------------------------------------------------------->
<br>
<h2><center>
    About Our Business</center>
</h2>
<pre>
    Sweet and Salty is one of the best store to buy online dry fruits in Pakistan. Currently, we are working only in Pakistan. Our main motive is to deliver fresh and
                        tasty dry fruits on the client’s doorstep. In our store, one will find the latest seasoned, premium quality dry fruits.

    Being famous and top seller of dry fruits in Pakistan, Sweet and Salty provides the best combination of nutrition and taste packed together for a healthy life.
</pre>
<h3><center>
    Benefits Of Dry Fruits</center>
</h3>
<pre>
    We all know that dry fruits are healthy and beneficial for both children and youngsters, everyone needs dry fruits in his daily routine life, but most of the time
       it is very hard to find the best quality dry fruits, especially in Pakistan. That’s why to vanish this difficulty the company has been developed in 2017.
   
    Dry fruits can boost the immunity system of the human body which helps to fight different diseases. Some dry fruits are beneficial for cancer, some nuts are best
                                         for weight loss. For women, dry fruits are very helpful and act as an anti-aging cure.
</pre>
<h3><center>
    Here is the list of some of our famous dry fruits</center>
</h3>
<pre>
            Kaghazi Almond, Almond Giri American, Walnuts Kaghazi China, Walnuts Giri, Apricots, Pista Irani, Kaju Roasted, Dates, Raisins (black, red, green),
                                                             Zarshik, pure shilajit, Chilghoza, imli, Charmaghaz
</pre> 


<!------------------------------------------------------FOOTER-------------------------------------------------------------->


            <footer class="page-footer font-small indigo">

                <!-- Footer Links -->
                <div class="container">
            
                <!-- Grid row-->
                <div class="row text-center d-flex justify-content-center pt-5 mb-3">
            
                    <!-- Grid column -->
                    <div class="col-md-2 mb-3">
                        <h6 class="text-uppercase font-weight-bold">
                            <a href="file:///G:/phase1/page2.html">About us</a>
                        </h6>
                        </div>
                        <!-- Grid column -->
                
                        <!-- Grid column -->
                        <div class="col-md-2 mb-3">
                        <h6 class="text-uppercase font-weight-bold">
                            <a href="file:///G:/phase1/page3.html">Products</a>
                        </h6>
                        </div>
                        <!-- Grid column -->
            
                        <!-- Grid column -->
                        <div class="col-md-2 mb-3">
                        <h6 class="text-uppercase font-weight-bold">
                            <a href="file:///G:/phase1/page4.html">Contact</a>
                        </h6>
                        </div>
                        <!-- Grid column -->
            
                </div>
                <!-- Grid row-->
                <hr class="rgba-white-light" style="margin: 0 15%;">
            
                <!-- Grid row-->
                <div class="row d-flex text-center justify-content-center mb-md-0 mb-4">
            
                    <!-- Grid column -->
                    <div class="col-md-8 col-12 mt-5">
                    <p style="line-height: 1.7rem">We provide best Quality Dry Nuts in best prices.We deliever online all type of Dry Nuts and 
                    Crackers with free home delivery and our products are also availabe in stores.</p>
                    </div>
                    <!-- Grid column -->
            
                </div>
                <!-- Grid row-->
                <hr class="clearfix d-md-none rgba-white-light" style="margin: 10% 15% 5%;">
            
                <!-- Grid row-->
                <div class="row pb-3">
            
                    <!-- Grid column -->
                    <div class="col-md-12">
            
                    <div>
                        
                        <nav class="navbar navbar-right" style="margin-right: 100px;">
                        <!-- Facebook -->
                        <a class="fb-ic">
                        <i class="fab fa-facebook-f fa-lg white-text mr-4" > </i>
                        <a  href="https://www.facebook.com/"><img src="fb.png" >
                        </a>
                        <!-- Twitter -->
                        <a class="tw-ic">
                        <i class="fab fa-twitter fa-lg white-text mr-4"> </i>
                        <a href="https://twitter.com/"><img src="tweet.png">
                        <!--Instagram-->
                        <a class="ins-ic">
                        <i class="fab fa-instagram fa-lg white-text mr-4"> </i>
                        <a href="https://instagram.com/"><img src="insta.png">
                        </a>
                        <!--Whastapp-->
                        <a class="ins-ic">
                            <i class="fab fa-whatsapp fa-lg white-text mr-4"> </i>
                            <a href="https://web.whatsapp.com/"><img src="whatsapp.png">
                            </a>
            
                    </div>
            
                    </div>
                    <!-- Grid column -->
            
                </div>
                <!-- Grid row-->
            
                </div>
                <!-- Footer Links -->
            
                <!-- Copyright -->
                <div class="footer-copyright text-center py-3">© 2020 Copyright:
                <a href="https://www.hyperstarpakistan.com/">Carrefore</a>
                </div>
            
            </footer>

    </body>
</html>